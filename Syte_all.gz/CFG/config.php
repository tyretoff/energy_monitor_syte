<?php
return [
    'servername' => 'localhost',
    'username' => 's817757_power',
    'password' => 'MPM6RTerpuDsKWZcCed4',
    'dbname' => 's817757_power',
];
?>